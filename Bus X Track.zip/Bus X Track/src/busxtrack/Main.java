package busxtrack;

import busxtrack.ui.LoginFrame;

public class Main {
    public static void main(String[] args) {
        LoginFrame loginFrame = new LoginFrame();
        loginFrame.setVisible(true);
    }
}
